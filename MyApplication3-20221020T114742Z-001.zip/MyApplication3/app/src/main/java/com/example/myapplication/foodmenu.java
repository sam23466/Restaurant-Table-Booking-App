package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class foodmenu extends AppCompatActivity {

    RecyclerView mRecyclerView;
    List<FoodData> myFoodList;
    FoodData mFoodData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foodmenu);

        mRecyclerView = (RecyclerView)findViewById(R.id.recyclerView);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(foodmenu.this,1);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        myFoodList = new ArrayList<>();

        mFoodData = new FoodData("Vegetable Soup","A thick, hearty tomato based soup loaded with fresh vegetables and herbs","Rs. 150",R.drawable.soup);
        myFoodList.add(mFoodData);
        mFoodData = new FoodData("Kababs","Beautifully rolled up using potatoes, green peas, spinach and a plethora of spices","Rs.200",R.drawable.kababa);
        myFoodList.add(mFoodData);
        mFoodData = new FoodData("Pasta","Spaghetti or Penne topped with your choice of meatballs or sausage. Stuffed with ricotta cheese and spinach,served with bolognese or marinara. ","Rs.300",R.drawable.pasta);
        myFoodList.add(mFoodData);
        mFoodData = new FoodData("Paneer","Delicious cottage cheese cooked in buttery fragrant gravy","Rs.350",R.drawable.paneer);
        myFoodList.add(mFoodData);
        mFoodData = new FoodData("Gulab Jamun","Soft, melt-in-your-mouth, fried dumplings that are traditionally made of thickened or reduced milk and soaked in rose-flavored sugar syrup.","Rs.150",R.drawable.gulab);
        myFoodList.add(mFoodData);
        mFoodData = new FoodData("Gajar Halwa","Combination of nuts, milk, sugar, khoya and ghee with grated carrot.","Rs.200",R.drawable.halwa);
        myFoodList.add(mFoodData);

        MyAdapter myAdapter = new MyAdapter(foodmenu.this,myFoodList);
        mRecyclerView.setAdapter(myAdapter);




    }


}
