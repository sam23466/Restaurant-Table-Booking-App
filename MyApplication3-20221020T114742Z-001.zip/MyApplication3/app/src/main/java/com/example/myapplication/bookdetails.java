package com.example.myapplication;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

import androidx.appcompat.app.AppCompatActivity;

public class bookdetails extends AppCompatActivity {
    DatabaseBook db;
    EditText tid;
    EditText ttime,tcontact,tname;
    Button b2;
    TimePickerDialog timePickerDialog;
    Calendar calendar;
    int currentHour;
    int currentMinute;
    String amPm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookdetails);
        db = new DatabaseBook(this);
        tid = (EditText)findViewById(R.id.tid);
        tname = (EditText)findViewById(R.id.tname);
        tcontact = (EditText)findViewById(R.id.tcontact);
        ttime= (EditText)findViewById(R.id.ttime);
        b2 = (Button)findViewById(R.id.tsubmit);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = tid.getText().toString();
                String s2 = tname.getText().toString();
                String s3 = tcontact.getText().toString();
                String s4 = ttime.getText().toString();
                if(s1.equals("")||s2.equals("")||s3.equals("")||s4.equals("")){
                    Toast.makeText(getApplicationContext(),"Please enter all details",Toast.LENGTH_SHORT).show();
                }
                else {
                    Boolean chktime = db.chktime(s1, s4);
                    if(chktime==true) {
                        Boolean insert = db.insert(s1,s2,s3,s4);
                        if(insert==true) {
                            Toast.makeText(getApplicationContext(),"Table Booked successfully",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(bookdetails.this,Menu.class));
                        }
                        else {
                            Toast.makeText(getApplicationContext(),"No insert",Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(getApplicationContext(),"This table is booked for this time slot",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        ttime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendar = Calendar.getInstance();
                currentHour = calendar.get(Calendar.HOUR_OF_DAY);
                currentMinute = calendar.get(Calendar.MINUTE);
                timePickerDialog = new TimePickerDialog(bookdetails.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                        if(hourOfDay>=12){
                            amPm="PM";
                        } else{
                            amPm="AM";
                        }
                        ttime.setText(String.format("%02d:%02d",hourOfDay,minutes)+amPm);
                        ttime.setText(hourOfDay + ":" + minutes);

                    }
                },0, 0,false);
                timePickerDialog.show();
            }
        });

        if(table.tableid == 1)
        {
            tid.setText("T1");
        }
        else if(table.tableid == 2)
        {
            tid.setText("T2");
        }
        else if(table.tableid == 3)
        {
            tid.setText("T3");
        }
        else if(table.tableid == 4)
        {
            tid.setText("T4");
        }
        else if(table.tableid == 5)
        {
            tid.setText("T5");
        }
        else if(table.tableid == 6)
        {
            tid.setText("T6");
        }
        else if(table.tableid == 7)
        {
            tid.setText("T7");
        }
        else
        {
            tid.setText("T8");
        }

    }
}
