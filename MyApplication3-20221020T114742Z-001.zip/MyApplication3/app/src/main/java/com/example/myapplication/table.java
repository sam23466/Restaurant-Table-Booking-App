package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class table extends AppCompatActivity {
    ImageView t1,t2,t3,t4,t5,t6,t7,t8;
    public static Integer tableid;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table);
        t1 = (ImageView)findViewById(R.id.T1);
        t2 = (ImageView)findViewById(R.id.T2);
        t3 = (ImageView)findViewById(R.id.T3);
        t4 = (ImageView)findViewById(R.id.T4);
        t5 = (ImageView)findViewById(R.id.T5);
        t6 = (ImageView)findViewById(R.id.T6);
        t7 = (ImageView)findViewById(R.id.T7);
        t8 = (ImageView)findViewById(R.id.T8);

        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tableid = 1;
                startActivity(new Intent(table.this,bookdetails.class));
            }
        });

        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tableid = 2;
                startActivity(new Intent(table.this,bookdetails.class));
            }
        });

        t3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tableid = 3;
                startActivity(new Intent(table.this,bookdetails.class));
            }
        });

        t4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tableid = 4;
                startActivity(new Intent(table.this,bookdetails.class));
            }
        });

        t5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tableid = 5;
                startActivity(new Intent(table.this,bookdetails.class));
            }
        });

        t6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tableid = 6;
                startActivity(new Intent(table.this,bookdetails.class));
            }
        });

        t7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tableid = 7;
                startActivity(new Intent(table.this,bookdetails.class));
            }
        });

        t8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tableid = 8;
                startActivity(new Intent(table.this,bookdetails.class));
            }
        });
    }
}
