package com.example.myapplication;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.app.AlertDialog.Builder;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class DatabaseBook extends SQLiteOpenHelper {
    public DatabaseBook(Context context) {
        super(context, "Booking.db", null, 2);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("Create table book(tableid text, name text, contact text primary key,ttime text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists book");

    }

    //inserting in database
    public boolean insert(String tableid, String name, String contact, String ttime) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("tableid", tableid);
        contentValues.put("name", name);
        contentValues.put("contact", contact);
        contentValues.put("ttime", ttime);
        long i = db.insert("book", null, contentValues);
        if (i == -1) return false;
        else return true;
    }
    //checking the time slot
    public Boolean chktime(String tableid, String ttime){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from book where tableid =? and ttime =?",new String[]{tableid,ttime});
        if(cursor.getCount()>0) return false;
        else return true;
    }

    public void view(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from book",null);
        if(cursor.getCount()==0){
            Toast.makeText(null,"Error! No bookings found.",Toast.LENGTH_SHORT).show();
        }
        StringBuffer buffer = new StringBuffer();
        while(cursor.moveToNext()){
            buffer.append("Table:"+ cursor.getString(0)+"\n");
            buffer.append("Name:"+ cursor.getString(1)+"\n");
            buffer.append("Contact:"+ cursor.getString(2)+"\n");
            buffer.append("Time:"+ cursor.getString(3)+"\n");
        }

    }


}
