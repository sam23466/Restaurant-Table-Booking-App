package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;


public class Menu extends AppCompatActivity {
    LinearLayout llmenu;
    LinearLayout llbook;
    LinearLayout llview;
    LinearLayout llout;
    DatabaseBook db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        final SQLiteDatabase db = getApplicationContext().openOrCreateDatabase("Booking.db", Context.MODE_PRIVATE,null);
        llmenu = (LinearLayout)findViewById(R.id.llmenu);
        llbook = (LinearLayout)findViewById(R.id.llbook);
        llview = (LinearLayout)findViewById(R.id.llview);
        llout = (LinearLayout)findViewById(R.id.llout);
        llmenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Menu.this,foodmenu.class));
            }
        });

        llbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Menu.this,table.class));
            }
        });

        llview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursor = db.rawQuery("Select * from book",null);
                if(cursor.getCount()==0){
                    Toast.makeText(null,"Error! No bookings found.",Toast.LENGTH_SHORT).show();
                }
                StringBuffer buffer = new StringBuffer();
                while(cursor.moveToNext()){
                    buffer.append("Table:"+ cursor.getString(0)+"\n");
                    buffer.append("Name:"+ cursor.getString(1)+"\n");
                    buffer.append("Contact:"+ cursor.getString(2)+"\n");
                    buffer.append("Time:"+ cursor.getString(3)+"\n\n");
                }
                showMessage("Booking Details",buffer.toString());



            }
        });
        llout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*Menu.super.on();
                startActivity(new Intent(Menu.this,MainActivity.class));*/
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);


            }
        });
        /*llout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Menu.super.finish();
                startActivity(new Intent(Menu.this,MainActivity.class));
                setContentView(R.layout.activity_log);
            }
        });*/


    }
    public void showMessage(String str1, String str2)
    {
        AlertDialog.Builder bob=new AlertDialog.Builder(this);
        bob.setCancelable(true);
        bob.setTitle(str1);
        bob.setMessage(str2);
        bob.show();
    }

}
